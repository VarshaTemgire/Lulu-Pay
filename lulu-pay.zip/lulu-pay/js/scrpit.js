$('input').focus(function () {
  $(this).parents('.form-group').addClass('focused');
});

$('input').blur(function () {
  var inputValue = $(this).val();
  if (inputValue == "") {
    $(this).removeClass('filled');
    $(this).parents('.form-group').removeClass('focused');
  } else {
    $(this).addClass('filled');
  }
});

$(document).ready(function () {
  $("#card_click").click(function () {
   showHide("card");
   
  });
  $("#upi_click").click(function () {
    showHide("upi");
  });
  $("#wallet_click").click(function () {
    showHide("wallet");
  });
  $("#net_banking_click").click(function () {
    showHide("net_banking");
  });
  $("#paylater_click").click(function () {
    showHide("paylater");
  });
  $("#cardless_emi_click").click(function () {
    showHide("cardless_emi");
  });

  $(".accordion-button").click(function () {
    var id = ($(this).attr("aria-expanded")=="true")?$(this).parent().attr("id"):'dummydummy';
    showMobileViewHide(id);
   });

  function showHide(id){
    $(".lulu-pay-menu").removeClass("text-white active");
    $('path',".lulu-pay-menu").attr("fill","#000");
    $('circle',".lulu-pay-menu").attr("stroke","#000");
    $('circle',".lulu-pay-menu").attr("fill","#fff");
    $('path',"#"+id+"_click").attr("fill","#fff");
    $("#"+id+"_click").addClass("text-white active");
    $(".payment_method").hide();
    $("#"+id).show();
    if(id=="cardless_emi"){
      $('circle',"#"+id+"_click").attr("stroke","#fff");
      $('circle',"#"+id+"_click").attr("fill","#02B9EF");
    }
  }

  function showMobileViewHide(id){
    $('path',".accordion-item").attr("fill","#000");
    $('circle',".accordion-item").attr("stroke","#000");
    $('circle',".accordion-item").attr("fill","#fff");
    $('g',"#"+id).attr("fill","#fff");
    $('path',"#"+id).attr("fill","#fff");
    if(id=="emi-accordion"){
      $('circle',"#"+id).attr("stroke","#fff");
      $('circle',"#"+id).attr("fill","#02B9EF");
    }
  }
});


