
var slider = $("#range").slider({
	range: "min",
	min: 0,
	max: 500,
	value: 0,
	slide: function (e, ui) {
	  updatePayByPoints(ui.value);
	  $(".ui-slider-handle").html(ui.value)
	  return;
	}
  });

  
  $(".ui-slider-handle").html("0");

  $("#Next").click(function () {
	var sliderCurrentValue = $("#range").slider("option", "value");
	if (sliderCurrentValue < 500) {
	  slider.slider("value", sliderCurrentValue + 1);
	  $(".ui-slider-handle").html(sliderCurrentValue + 1);
	  updatePayByPoints(sliderCurrentValue + 1)
	  return;
	}
  });
  
  $("#Back").click(function () {
	var sliderCurrentValue = $("#range").slider("option", "value");
	if (sliderCurrentValue > 0) {
	  const points = Number($('#points1').html())
	  slider.slider("value", sliderCurrentValue - 1);
	  $(".ui-slider-handle").html(sliderCurrentValue - 1);
	  updatePayByPoints(sliderCurrentValue - 1);
	  return;
	}
  });

  const originalAmount = 5000;
  $('#final-amount').html(originalAmount);
  
  $("#final-amount-checkbox").change(function(event) {
	if (this.checked) {
	  const points = Number($('#points1').html())
	  $('#final-amount').html(originalAmount - points);
	} else {
	  $('#final-amount').html(originalAmount);
	}
  }); 
  
  function updatePayByPoints(value) {
	$('#points1').html(value);
	$('#points-rupees').html(value);
	if ($('#final-amount-checkbox').is(':checked')) {
		$('#final-amount').html(originalAmount - value);
	  }
  }

 
// for mobile layalty patch


var slider1 = $("#range1").slider({
	range: "min",
	min: 0,
	max: 500,
	value: 0,
	slide: function (e, ui) {
	  updatePayByPoints1(ui.value);
	  $(".ui-slider-handle").html(ui.value)
	  return;
	}
  });

  
  $(".ui-slider-handle").html("0");

  $("#Next1").click(function () {
	var sliderCurrentValue1 = $("#range1").slider("option", "value");
	if (sliderCurrentValue1 < 500) {
	  slider1.slider("value", sliderCurrentValue1 + 1);
	  $(".ui-slider-handle").html(sliderCurrentValue1 + 1);
	  updatePayByPoints1(sliderCurrentValue1 + 1)
	  return;
	}
  });
  
  $("#Back1").click(function () {
	var sliderCurrentValue1 = $("#range1").slider("option", "value");
	if (sliderCurrentValue1 > 0) {
	  const points = Number($('#points11').html())
	  slider1.slider("value", sliderCurrentValue1 - 1);
	  $(".ui-slider-handle").html(sliderCurrentValue1 - 1);
	  updatePayByPoints1(sliderCurrentValue1 - 1);
	  return;
	}
  });

  const originalAmount1 = 5000;
  $('#final-amount1').html(originalAmount1);
  
  $("#final-amount-checkbox1").change(function(event) {
	if (this.checked) {
	  const points1 = Number($('#points11').html())
	  $('#final-amount1').html(originalAmount1 - points1);
	} else {
	  $('#final-amount1').html(originalAmount1);
	}
  }); 
  
  function updatePayByPoints1(value) {
	$('#points11').html(value);
	$('#points-rupees1').html(value);
	if ($('#final-amount-checkbox1').is(':checked')) {
		$('#final-amount1').html(originalAmount1 - value);
	  }
  }

 



